#include "ui/PanelSignals.h"
namespace ui {
bool g_signal_open_economy = false;
bool g_signal_open_military = false;
bool g_signal_open_agents  = false;
} // namespace ui
