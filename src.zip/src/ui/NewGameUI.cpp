
#include "imgui.h"
namespace ui {
    struct AppState;
    // Simple New Game modal
    void DrawNewGame(AppState&) {
        ImGui::Begin("New Game");
        ImGui::Text("Start a new campaign (placeholder)");
        if (ImGui::Button("Close")) {
            // no-op: the real handler can set state flags
        }
        ImGui::End();
    }
} // namespace ui
