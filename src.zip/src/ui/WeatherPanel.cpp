#include "ui/WeatherPanel.h"
#include "imgui.h"
#include "ui/PanelCommon.h"
#include <vector>
#include <string>
#include <algorithm>

using namespace ui;

namespace ui::panels {

static int   gSort_weather = 0;
static char  gSearch_weather[64] = {0};
static int   gSelected_weather = -1;

void WeatherPanel::Draw(core::SimulationState& sim, float /*width*/) {
    ImGui::SetNextItemWidth(160);
    ImGui::InputTextWithHint("##search_weather", "Search", gSearch_weather, sizeof(gSearch_weather));
    ImGui::SameLine();
    if (ImGui::BeginCombo("Sort##weather", gSort_weather==0 ? "Visibility" : "Name")) {
        bool s0 = (gSort_weather==0);
        bool s1 = (gSort_weather==1);
        if (ImGui::Selectable("Visibility", s0)) gSort_weather=0;
        if (ImGui::Selectable("Name", s1))       gSort_weather=1;
        ImGui::EndCombo();
    }

    const auto& W = sim.weather();
    std::vector<int> idx;
    idx.reserve((int)W.size());
    for (int i=0;i<(int)W.size();++i) {
        if (matchesSearch(W[i].name.c_str(), gSearch_weather)) idx.push_back(i);
    }
    std::sort(idx.begin(), idx.end(), [&](int a, int b){
        if (gSort_weather==0) return W[a].visibility > W[b].visibility;
        return W[a].name < W[b].name;
    });

    ImGui::Separator();
    ImGuiListClipper clip;
    clip.Begin((int)idx.size());
    while (clip.Step()) {
        for (int _i=clip.DisplayStart; _i<clip.DisplayEnd; ++_i) {
            int i = idx[_i];
            const auto& w = W[i];
            std::string label = w.name + "  (" + w.weather + ")##weather-" + std::to_string(i);
            bool selected = (gSelected_weather==i);
            if (ImGui::Selectable(label.c_str(), selected)) gSelected_weather=i;

            ImGui::SameLine();
            ImGui::SetCursorPosX(ImGui::GetContentRegionMax().x - 120);
            ImGui::Text("vis %.0f%%", w.visibility*100.0f);
        }
    }
}

void WeatherPanel::DrawDetails(core::SimulationState& sim) {
    int i = gSelected_weather;
    if (i < 0) { ImGui::TextUnformatted("Select a row to see details."); return; }
    const auto& w = sim.weather()[i];
    ImGui::Text("Region: %s", w.name.c_str());
    ImGui::Separator();
    ImGui::Text("Weather: %s", w.weather.c_str());
    ImGui::Text("Visibility: %.0f%%", w.visibility*100.0f);
}

} // namespace ui::panels
