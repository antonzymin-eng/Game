#include "ui/SelectionContext.h"
namespace ui {
static SelectionContext g_ctx;
SelectionContext& UX() { return g_ctx; }
} // namespace ui
