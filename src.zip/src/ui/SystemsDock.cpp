#include "ui/SystemsDock.h"
#include "imgui.h"
#include "imgui_internal.h"
#include "ui/MapAPI.h"

namespace ui {

    struct DockState {
        bool pEconomy = false, pMilitary = false, pDiplomacy = false, pEspionage = false, pTrade = false;
        bool pReligion = false, pTech = false, pCourt = false, pAdvisors = false, pLaws = false, pPopulation = false;
    };
    static DockState& S() { static DockState s; return s; }

    static void IconButton(const char* id, const char* label, bool* toggle) {
        ImVec2 sz(36, 36);
        ImGui::PushID(id);
        if (*toggle) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.60f, 0.25f, 1));
        bool pressed = ImGui::Button(label, sz);
        if (*toggle) ImGui::PopStyleColor();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", label);
        if (pressed) *toggle = !*toggle;
        ImGui::PopID();
    }

    static void PanelWindow(const char* title, bool* open) {
        if (!*open) return;
        ImVec2 sz(380, 360);
        ImGui::SetNextWindowSize(sz, ImGuiCond_Appearing);
        ImGui::Begin(title, open, ImGuiWindowFlags_NoSavedSettings);
        auto info = MapGetInfo();
        ImGui::TextDisabled("Map: %s (%dx%d), Provinces: %d", info.loaded ? "loaded" : "missing", info.width, info.height, MapGetProvinceCount());
        ImGui::Separator();
        ImGui::Text("Content for %s goes here.", title);
        ImGui::End();
    }

    void SystemsDock_Draw() {
        const ImGuiViewport* vp = ImGui::GetMainViewport();

        // LEFT strip — pinned
        ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + 6, vp->Pos.y + 80), ImGuiCond_Always);
        ImGui::Begin("##DockStripL", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking);
        IconButton("eco", "£", &S().pEconomy);   ImGui::Dummy(ImVec2(0, 4));
        IconButton("mil", "⚔", &S().pMilitary);  ImGui::Dummy(ImVec2(0, 4));
        IconButton("dip", "✶", &S().pDiplomacy); ImGui::Dummy(ImVec2(0, 4));
        IconButton("esp", "⟂", &S().pEspionage); ImGui::Dummy(ImVec2(0, 4));
        IconButton("trd", "⌁", &S().pTrade);
        ImGui::End();

        // RIGHT strip — pinned
        ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x - 46, vp->Pos.y + 80), ImGuiCond_Always);
        ImGui::Begin("##DockStripR", nullptr,
            ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking);
        IconButton("rel", "✝", &S().pReligion);  ImGui::Dummy(ImVec2(0, 4));
        IconButton("tec", "⌘", &S().pTech);      ImGui::Dummy(ImVec2(0, 4));
        IconButton("crt", "⚜", &S().pCourt);     ImGui::Dummy(ImVec2(0, 4));
        IconButton("adv", "♜", &S().pAdvisors);  ImGui::Dummy(ImVec2(0, 4));
        IconButton("law", "§", &S().pLaws);      ImGui::Dummy(ImVec2(0, 4));
        IconButton("pop", "☧", &S().pPopulation);
        ImGui::End();

        // Popout placeholders
        PanelWindow("Economy", &S().pEconomy);
        PanelWindow("Military", &S().pMilitary);
        PanelWindow("Diplomacy", &S().pDiplomacy);
        PanelWindow("Espionage", &S().pEspionage);
        PanelWindow("Trade", &S().pTrade);
        PanelWindow("Religion", &S().pReligion);
        PanelWindow("Technology", &S().pTech);
        PanelWindow("Court", &S().pCourt);
        PanelWindow("Advisors", &S().pAdvisors);
        PanelWindow("Laws", &S().pLaws);
        PanelWindow("Population", &S().pPopulation);
    }
} // namespace ui
