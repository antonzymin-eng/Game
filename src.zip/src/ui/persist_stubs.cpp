
// Linker stubs for persist::* used by PauseMenu until real persistence is wired.
namespace persist {
    struct Settings;
    bool LoadSettings(Settings&) { return false; }
    bool SaveSettings(Settings const&) { return false; }
    void ApplySettings(Settings const&) {}
} // namespace persist
