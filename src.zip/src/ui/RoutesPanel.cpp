#include "imgui.h"



// Minimal forward declarations to avoid including the whole project headers
namespace core { class SimulationState; }

namespace ui { namespace panels {
struct FactionsPanel; struct AgentsPanel; struct EconomyPanel; struct TradePanel;
struct RoutesPanel; struct MilitaryPanel; struct NavalPanel; struct TechPanel;
struct PopulationPanel; struct EventsPanel;
} } // namespaces

    using namespace ImGui;

    namespace ui { namespace panels {

struct RoutesPanel {
    static void Draw(core::SimulationState& sim, float width);
    static void DrawDetails(core::SimulationState& sim);
};


    void RoutesPanel::Draw(core::SimulationState&, float) {
        if (Begin("RoutesPanel")) {
            Text("RoutesPanel panel (placeholder)");
        }
        End();
    }

    void RoutesPanel::DrawDetails(core::SimulationState&) {
        if (Begin("RoutesPanel Details")) {
            Text("RoutesPanel details (placeholder)");
        }
        End();
    }

    } } // namespace ui::panels
