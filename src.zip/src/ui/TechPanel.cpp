#include "imgui.h"



// Minimal forward declarations to avoid including the whole project headers
namespace core { class SimulationState; }

namespace ui { namespace panels {
struct FactionsPanel; struct AgentsPanel; struct EconomyPanel; struct TradePanel;
struct RoutesPanel; struct MilitaryPanel; struct NavalPanel; struct TechPanel;
struct PopulationPanel; struct EventsPanel;
} } // namespaces

    using namespace ImGui;

    namespace ui { namespace panels {

struct TechPanel {
    static void Draw(core::SimulationState& sim, float width);
    static void DrawDetails(core::SimulationState& sim);
};


    void TechPanel::Draw(core::SimulationState&, float) {
        if (Begin("TechPanel")) {
            Text("TechPanel panel (placeholder)");
        }
        End();
    }

    void TechPanel::DrawDetails(core::SimulationState&) {
        if (Begin("TechPanel Details")) {
            Text("TechPanel details (placeholder)");
        }
        End();
    }

    } } // namespace ui::panels
