// src/ui/Theme.cpp (v5 — brighter medieval palette + robust font auto-load)
#include "imgui.h"
#include <fstream>

namespace ui {

static ImVec4 RGB(int r,int g,int b,float a=1.0f){return ImVec4(r/255.0f,g/255.0f,b/255.0f,a);}

static bool FileExists(const char* path){
    std::ifstream f(path, std::ios::binary);
    return f.good();
}

void SetupImGuiStyle()
{
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    ImVec4* c = s.Colors;

    // Brighter, warmer medieval palette (not black)
    const ImVec4 WindowBg  = RGB(45, 39, 32);   // warm parchment-dim
    const ImVec4 PanelBg   = RGB(54, 48, 40);
    const ImVec4 TopBarBg  = RGB(50, 44, 36);
    const ImVec4 Accent    = RGB(224, 180, 92); // antique gold
    const ImVec4 AccentHi  = RGB(240, 197, 110);
    const ImVec4 Frame     = RGB(68, 61, 52);
    const ImVec4 FrameHi   = RGB(82, 74, 64);
    const ImVec4 Border    = RGB(100, 92, 79);
    const ImVec4 TextHi    = RGB(251, 247, 236);
    const ImVec4 TextMute  = RGB(205, 198, 186);

    s.WindowRounding = 8.0f;
    s.FrameRounding  = 7.0f;
    s.GrabRounding   = 7.0f;
    s.PopupRounding  = 8.0f;
    s.ScrollbarRounding = 6.0f;
    s.TabRounding    = 8.0f;
    s.FrameBorderSize = 1.0f;
    s.WindowBorderSize = 1.0f;
    s.Alpha = 1.0f;

    c[ImGuiCol_Text]           = TextHi;
    c[ImGuiCol_TextDisabled]   = TextMute;
    c[ImGuiCol_WindowBg]       = WindowBg;
    c[ImGuiCol_ChildBg]        = PanelBg;
    c[ImGuiCol_PopupBg]        = PanelBg;
    c[ImGuiCol_Border]         = Border;
    c[ImGuiCol_BorderShadow]   = ImVec4(0,0,0,0);

    c[ImGuiCol_FrameBg]        = Frame;
    c[ImGuiCol_FrameBgHovered] = FrameHi;
    c[ImGuiCol_FrameBgActive]  = FrameHi;

    c[ImGuiCol_TitleBg]        = TopBarBg;
    c[ImGuiCol_TitleBgActive]  = TopBarBg;
    c[ImGuiCol_TitleBgCollapsed] = TopBarBg;

    c[ImGuiCol_MenuBarBg]      = TopBarBg;

    c[ImGuiCol_ScrollbarBg]    = PanelBg;
    c[ImGuiCol_ScrollbarGrab]  = FrameHi;
    c[ImGuiCol_ScrollbarGrabHovered] = Accent;
    c[ImGuiCol_ScrollbarGrabActive]  = AccentHi;

    c[ImGuiCol_CheckMark]      = Accent;
    c[ImGuiCol_SliderGrab]     = Accent;
    c[ImGuiCol_SliderGrabActive] = AccentHi;

    c[ImGuiCol_Button]         = Frame;
    c[ImGuiCol_ButtonHovered]  = FrameHi;
    c[ImGuiCol_ButtonActive]   = Accent;

    // Tabs & headers
    c[ImGuiCol_Header]         = RGB(94, 86, 74);
    c[ImGuiCol_HeaderHovered]  = RGB(112, 104, 90);
    c[ImGuiCol_HeaderActive]   = Accent;

    c[ImGuiCol_Tab]            = RGB(120, 110, 94);
    c[ImGuiCol_TabHovered]     = RGB(140, 130, 112);
    c[ImGuiCol_TabActive]      = RGB(132, 122, 106);
    c[ImGuiCol_TabUnfocusedActive] = c[ImGuiCol_TabActive];

    c[ImGuiCol_Separator]      = Border;
    c[ImGuiCol_ResizeGrip]     = FrameHi;
    c[ImGuiCol_ResizeGripHovered] = Accent;
    c[ImGuiCol_ResizeGripActive]  = AccentHi;

    c[ImGuiCol_NavHighlight]   = Accent;
    c[ImGuiCol_NavWindowingHighlight] = Accent;

    // Try to load a medieval-esque font automatically (assets first, then common Windows fonts)
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig cfg; cfg.OversampleH = 3; cfg.OversampleV = 2; cfg.PixelSnapH = true;
    const float fontSize = 20.0f;

    const char* tryPaths[] = {
        // Project assets
        "assets/fonts/medieval.ttf",
        "assets/fonts/IMFellEnglish-Regular.ttf",
        "assets/fonts/MedievalSharp-Regular.ttf",
        "assets/fonts/UnifrakturCook-Bold.ttf",
        "assets/fonts/Cinzel-Regular.ttf",
        // Common Windows installs (filenames vary by locale; try several)
        "C:\\Windows\\Fonts\\OLDENGL.TTF",        // Old English Text MT
        "C:\\Windows\\Fonts\\Blackadder ITC.ttf",// Blackadder ITC (name may vary)
        "C:\\Windows\\Fonts\\ITCBLKAD.TTF",      // Blackadder ITC alt
        "C:\\Windows\\Fonts\\CINZEL-REGULAR.TTF",
        "C:\\Windows\\Fonts\\IMFELLENGLISH-REGULAR.TTF",
    };
    ImFont* med = nullptr;
    for (auto p : tryPaths) {
        if (FileExists(p)) { med = io.Fonts->AddFontFromFileTTF(p, fontSize, &cfg); if (med) break; }
    }
    if (med) io.FontDefault = med; // switch to medieval-looking font if found
}

} // namespace ui
