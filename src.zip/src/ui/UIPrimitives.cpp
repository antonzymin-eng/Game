
#include "imgui.h"

namespace ui {

// Center the next window and set its size. pivot in [0..1] (0.5 = centered)
void CenterNextWindow(float width, float height, float pivot) {
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 size(width, height);
    ImVec2 center(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
    ImVec2 pos(center.x - size.x * pivot, center.y - size.y * pivot);
    ImGui::SetNextWindowPos(pos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(size, ImGuiCond_Always);
}

// Fill the entire viewport with a translucent color (alpha 0..1)
void FillViewportBackground(float alpha) {
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImDrawList* bg = ImGui::GetBackgroundDrawList(vp);
    ImU32 col = ImGui::ColorConvertFloat4ToU32(ImVec4(0.0f, 0.0f, 0.0f, alpha));
    bg->AddRectFilled(vp->Pos, ImVec2(vp->Pos.x + vp->Size.x, vp->Pos.y + vp->Size.y), col);
}

} // namespace ui
