#include "ui/PauseMenu.h"
#include "io/SaveLoad.h"
#include "imgui.h"

namespace ui {

    void DrawPauseMenu(AppState& app) {
        if (!app.pauseMenuOpen) return;

        ImGui::SetNextWindowBgAlpha(0.90f);
        ImGui::SetNextWindowSize(ImVec2(480, 420), ImGuiCond_Appearing);
        ImGui::Begin("Game Menu", &app.pauseMenuOpen, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);

        if (ImGui::Button("Resume", ImVec2(-1, 36))) app.pauseMenuOpen = false;

        if (ImGui::Button("Save Game", ImVec2(-1, 36))) io::SaveLoadManager::I().quickSave();
        if (ImGui::Button("Quick Load (latest)", ImVec2(-1, 36))) io::SaveLoadManager::I().loadLatest();

        ImGui::Separator();
        if (ImGui::Button("Exit to Main Menu", ImVec2(-1, 36))) {
            app.pauseMenuOpen = false;
            app.screen = ui::Screen::MainMenu;  // <-- switch screen immediately
        }

        ImGui::End();
    }

} // namespace ui
