#include "ui/Notify.h"
#include "state/EventBus.h"
#include "ui/Toast.h"

namespace ui {

    static bool g_registered = false;

    void RegisterBusUIHandler() {
        if (g_registered) return;
        g_registered = true;

        // Bridge engine bus -> UI toasts
        core::bus::registerHandler([](const core::bus::Command&) {
            ui::Toast("Command queued");
            });
    }

} // namespace ui
