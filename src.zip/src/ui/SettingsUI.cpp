#include "imgui.h"
#include "ScreenAPI.h"

namespace ui {

static Screen g_return_screen = Screen::MainMenu;

void SettingsSetReturn(Screen s) { g_return_screen = s; }

void DrawSettings(AppState& app) {
    static bool open = true;
    static bool initialized = false;

    // Persistent settings variables (portable, MSVC-friendly)
    static float master_volume = 0.75f;
    static bool  vsync_enabled = true;
    static bool  fullscreen    = false;

    // Re-initialize 'open' when we enter this screen
    if (!initialized) { open = true; initialized = true; }
    if (app.screen != Screen::Settings) { initialized = false; return; }

    if (ImGui::Begin("Settings", &open, ImGuiWindowFlags_NoCollapse)) {
        ImGui::TextDisabled("Settings");
        ImGui::Separator();

        // --- Audio ---
        ImGui::Text("Audio");
        ImGui::SliderFloat("Master Volume", &master_volume, 0.0f, 1.0f, "%.2f");

        // --- Graphics ---
        ImGui::Text("Graphics");
        ImGui::Checkbox("VSync", &vsync_enabled);
        ImGui::Checkbox("Fullscreen", &fullscreen);

        ImGui::Spacing();
        if (ImGui::Button("Close")) {
            open = false;
        }
    }
    ImGui::End();

    if (!open) {
        // Return to the screen that opened settings
        app.screen = g_return_screen;
        open = true;        // reset for next time
        initialized = false;
    }
}

} // namespace ui