
#include "ui/Style.h"
#include "imgui.h"
namespace ui {
void ApplyMedievalTheme(float font_scale) {
    ImGuiIO& io = ImGui::GetIO();
    io.FontGlobalScale = font_scale;
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 8.0f; s.FrameRounding = 6.0f; s.GrabRounding = 6.0f; s.TabRounding = 6.0f;
    s.WindowBorderSize = 2.0f; s.FrameBorderSize = 1.5f; s.TabBorderSize = 1.0f;
    ImVec4 parchment = ImVec4(0.91f,0.85f,0.71f,1.00f);
    ImVec4 wood      = ImVec4(0.35f,0.24f,0.17f,1.00f);
    ImVec4 wood2     = ImVec4(0.28f,0.19f,0.14f,1.00f);
    ImVec4 gold      = ImVec4(0.79f,0.64f,0.15f,1.00f);
    ImVec4 gold_dim  = ImVec4(0.58f,0.47f,0.11f,1.00f);
    ImVec4 ink       = ImVec4(0.17f,0.13f,0.10f,1.00f);
    ImVec4 parchment_dim = ImVec4(0.86f,0.80f,0.66f,1.00f);
    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = ink; c[ImGuiCol_TextDisabled] = ImVec4(ink.x,ink.y,ink.z,0.6f);
    c[ImGuiCol_WindowBg] = parchment; c[ImGuiCol_ChildBg] = parchment_dim; c[ImGuiCol_PopupBg] = parchment;
    c[ImGuiCol_Border] = gold_dim; c[ImGuiCol_BorderShadow] = wood2;
    c[ImGuiCol_FrameBg] = ImVec4(wood.x,wood.y,wood.z,0.50f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(wood.x,wood.y,wood.z,0.70f);
    c[ImGuiCol_FrameBgActive]  = wood;
    c[ImGuiCol_TitleBg] = wood2; c[ImGuiCol_TitleBgActive] = wood; c[ImGuiCol_TitleBgCollapsed] = wood2;
    c[ImGuiCol_MenuBarBg] = wood2;
    c[ImGuiCol_ScrollbarBg] = parchment_dim;
    c[ImGuiCol_ScrollbarGrab] = gold_dim; c[ImGuiCol_ScrollbarGrabHovered] = gold; c[ImGuiCol_ScrollbarGrabActive] = gold;
    c[ImGuiCol_CheckMark] = gold; c[ImGuiCol_SliderGrab] = gold_dim; c[ImGuiCol_SliderGrabActive] = gold;
    c[ImGuiCol_Button] = wood; c[ImGuiCol_ButtonHovered] = ImVec4(wood.x,wood.y,wood.z,0.85f); c[ImGuiCol_ButtonActive] = wood2;
    c[ImGuiCol_Header] = ImVec4(wood.x,wood.y,wood.z,0.60f);
    c[ImGuiCol_HeaderHovered] = ImVec4(wood.x,wood.y,wood.z,0.80f);
    c[ImGuiCol_HeaderActive]  = wood;
    c[ImGuiCol_Separator] = gold_dim; c[ImGuiCol_SeparatorHovered] = gold; c[ImGuiCol_SeparatorActive] = gold;
    c[ImGuiCol_ResizeGrip] = gold_dim; c[ImGuiCol_ResizeGripHovered] = gold; c[ImGuiCol_ResizeGripActive] = gold;
    c[ImGuiCol_Tab] = ImVec4(wood.x,wood.y,wood.z,0.80f);
    c[ImGuiCol_TabHovered] = ImVec4(wood.x,wood.y,wood.z,0.95f);
    c[ImGuiCol_TabActive] = wood;
    c[ImGuiCol_TabUnfocused] = ImVec4(wood.x,wood.y,wood.z,0.60f);
    c[ImGuiCol_TabUnfocusedActive] = wood;
    c[ImGuiCol_TableHeaderBg] = wood2; c[ImGuiCol_TableBorderStrong] = gold_dim; c[ImGuiCol_TableBorderLight] = gold_dim;
    c[ImGuiCol_TableRowBg] = ImVec4(parchment_dim.x,parchment_dim.y,parchment_dim.z,0.40f);
    c[ImGuiCol_TableRowBgAlt] = ImVec4(parchment_dim.x,parchment_dim.y,parchment_dim.z,0.20f);
    c[ImGuiCol_DragDropTarget] = gold;
    c[ImGuiCol_NavHighlight] = gold; c[ImGuiCol_NavWindowingHighlight] = gold;
    c[ImGuiCol_NavWindowingDimBg] = ImVec4(0,0,0,0.2f); c[ImGuiCol_ModalWindowDimBg] = ImVec4(0,0,0,0.3f);
}
} // namespace ui
