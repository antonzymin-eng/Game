
// Minimal stubs to satisfy linker for stbi_* if stb_image implementation isn't linked yet.
extern "C" {
    unsigned char* stbi_load(const char*, int*, int*, int*, int) { return nullptr; }
    void stbi_image_free(void*) {}
}
