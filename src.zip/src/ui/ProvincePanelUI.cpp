#include "ui/ProvincePanel.h"
#include "ui/MapAPI.h"
#include "ui/BuildingsUI.h"
#include "imgui.h"

namespace ui{
void ProvincePanel_Show(int pid, const char* pname, bool* open){
    if(!*open) return;
    ProvinceSummary ps{}; MapGetProvinceSummary(pid,&ps);
    ImGui::SetNextWindowSize(ImVec2(520,560),ImGuiCond_Appearing);
    if(ImGui::Begin("Province", open, ImGuiWindowFlags_NoSavedSettings)){
        ImGui::TextDisabled("%s", pname?pname:"—"); ImGui::Separator();
        ImGui::Columns(2,nullptr,false);
        ImGui::Text("Owner: %s", ps.owner?ps.owner:"—"); ImGui::NextColumn();
        ImGui::Text("Terrain: %s", ps.terrain?ps.terrain:"—"); ImGui::NextColumn();
        ImGui::Text("Population: %s","—"); ImGui::NextColumn();
        ImGui::Text("Economy: %s","—"); ImGui::NextColumn();
        ImGui::Text("Cultures: %s","—"); ImGui::NextColumn();
        ImGui::Text("Religions: %s","—"); ImGui::NextColumn();
        ImGui::Text("Social Classes: %s","—"); ImGui::NextColumn();
        ImGui::Text("Unrest: %s","—"); ImGui::NextColumn();
        ImGui::Text("Military Units: %s","—"); ImGui::NextColumn();
        ImGui::Columns(1); ImGui::Separator();
        if(ImGui::Button("Open Espionage")){}
        ImGui::SameLine();
        if(ImGui::Button("Open Trade")){}
        ImGui::Separator();
        static bool showBuild=true;
        BuildingsUI_ShowForProvince(pid,pname,&showBuild);
    } ImGui::End();
}
}
