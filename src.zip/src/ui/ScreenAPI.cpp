#include "ScreenAPI.h"

namespace ui {
    static AppState g_app;          // global app state instance
    AppState& App() { return g_app; }
} // namespace ui
