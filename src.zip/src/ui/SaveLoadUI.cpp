
#include "imgui.h"
#include <vector>
#include <string>
#include <cstring>
#include "ui/SaveLoadUI.h"
#include "io/SaveLoad.h"
#include "ui/Toast.h"

namespace ui { namespace SaveLoadUI {

static bool g_open_save = false;
static bool g_open_load = false;
static bool g_loaded_flag = false;
static char g_save_name[128] = {0};

static void DrawSaveModal() {
    if (!g_open_save) return;
    ImGui::OpenPopup("Save Game");
    if (ImGui::BeginPopupModal("Save Game", &g_open_save, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextWrapped("Enter a name for your save:");
        ImGui::Spacing();
        ImGui::InputText("##savename", g_save_name, IM_ARRAYSIZE(g_save_name));
        ImGui::Spacing();

        if (ImGui::Button("Save", ImVec2(140, 0))) {
            if (g_save_name[0] == '\0') {
                snprintf(g_save_name, IM_ARRAYSIZE(g_save_name), "save_%lld",
                    (long long)(ImGui::GetTime()));
            }
            const bool ok = io::SaveLoadManager::I().saveAs(std::string(g_save_name));
            if (ok) {
                ui::ToastManager::I().Add("Save completed", 3.0f);
                g_open_save = false;
                ImGui::CloseCurrentPopup();
            } else {
                ImGui::SameLine();
                ImGui::TextColored(ImVec4(1,0.5f,0.2f,1),"  Failed to save.");
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel", ImVec2(140, 0))) {
            g_open_save = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
}

static void DrawLoadModal() {
    if (!g_open_load) return;
    ImGui::OpenPopup("Load Game");
    if (ImGui::BeginPopupModal("Load Game", &g_open_load, ImGuiWindowFlags_AlwaysAutoResize)) {
        const auto saves = io::SaveLoadManager::I().listSaves();
        if (saves.empty()) {
            ImGui::TextDisabled("No saved games found.");
        } else {
            ImGui::TextUnformatted("Select a save to load:");
            ImGui::Separator();
            ImGui::BeginChild("##savelist", ImVec2(460, 260), true, ImGuiWindowFlags_AlwaysVerticalScrollbar);
            for (const auto& s : saves) {
                ImGui::PushID(s.name.c_str());
                ImGui::TextUnformatted(s.name.c_str());
                ImGui::SameLine();
                if (ImGui::Button("Load")) {
                    if (io::SaveLoadManager::I().loadByName(s.name)) {
                        g_loaded_flag = true;
                        ui::ToastManager::I().Add("Save loaded", 2.0f);
                        g_open_load = false;
                        ImGui::CloseCurrentPopup();
                        ImGui::PopID();
                        break;
                    } else {
                        ImGui::SameLine();
                        ImGui::TextColored(ImVec4(1,0.5f,0.2f,1),"  Failed.");
                    }
                }
                ImGui::PopID();
            }
            ImGui::EndChild();
        }
        if (ImGui::Button("Close", ImVec2(140, 0))) {
            g_open_load = false;
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }
}

void RenderModals() {
    DrawSaveModal();
    DrawLoadModal();
}

void OpenSaveModal(const char* /*source*/) {
    g_save_name[0] = '\0';
    g_open_save = true;
}
void OpenLoadModal(const char* /*source*/) {
    g_open_load = true;
}

bool ConsumeLoadedFlag() {
    const bool v = g_loaded_flag;
    g_loaded_flag = false;
    return v;
}

}} // namespace ui::SaveLoadUI
