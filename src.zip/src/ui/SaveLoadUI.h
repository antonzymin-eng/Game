#pragma once
// src/ui/SaveLoadUI.h (v7 — unified Save/Load modals with file listing & delete/overwrite)
#include <string>
#include <vector>

namespace ui {
namespace SaveLoadUI {

// Open the Save or Load modal next frame
void OpenSave();
void OpenLoad();

// Call every frame from any screen to render modals if opened
void Render();

// Optional: set/get preferred saves directory (defaults: ./saves, ./Saves, ./save, ./Save)
void SetSavesDirectory(const std::string& path);
const std::string& GetSavesDirectory();

} // namespace SaveLoadUI
} // namespace ui
