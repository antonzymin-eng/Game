#include "imgui.h"
#include "ui/Toast.h"

namespace ui {

ToastManager& ToastManager::I() {
    static ToastManager inst;
    return inst;
}

void ToastManager::Add(const std::string& text, float duration_sec) {
    Item it;
    it.text = text;
    it.duration = duration_sec > 0.0f ? duration_sec : 0.001f;
    it.start_time = ImGui::GetTime();
    items_.push_back(it);
}

void ToastManager::Render() {
    if (items_.empty()) return;
    const double now = ImGui::GetTime();

    // Purge fully expired items
    for (size_t i = 0; i < items_.size();) {
        const Item& it = items_[i];
        const float t = float(now - it.start_time);
        if (t > it.duration + 0.35f) items_.erase(items_.begin() + i);
        else ++i;
    }
    if (items_.empty()) return;

    // Draw only the most recent active toast
    const Item& it = items_.back();
    const float t = float(now - it.start_time);
    const float life = it.duration;
    float alpha = 1.0f;
    if (t > life * 0.75f) {
        const float fade_t = t - life * 0.75f;
        const float fade_d = life * 0.25f;
        alpha = 1.0f - (fade_t / (fade_d <= 0.001f ? 0.001f : fade_d));
        if (alpha < 0.03f) alpha = 0.03f;
    }

    ImDrawList* fg = ImGui::GetForegroundDrawList();
    ImGuiViewport* vp = ImGui::GetMainViewport();

    const char* msg = it.text.c_str();
    ImVec2 text_size = ImGui::CalcTextSize(msg);
    const float pad = 16.0f;
    ImVec2 box = ImVec2(text_size.x + pad * 2.0f, text_size.y + pad * 2.0f);

    // Slightly above center for better UX
    ImVec2 center = ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.45f);
    ImVec2 min = ImVec2(center.x - box.x * 0.5f, center.y - box.y * 0.5f);
    ImVec2 max = ImVec2(center.x + box.x * 0.5f, center.y + box.y * 0.5f);

    ImU32 bg = ImGui::GetColorU32(ImVec4(0.06f, 0.07f, 0.09f, 0.93f * alpha));
    ImU32 bd = ImGui::GetColorU32(ImVec4(0.88f, 0.78f, 0.45f, 0.95f * alpha)); // antique gold
    ImU32 tx = ImGui::GetColorU32(ImVec4(0.92f, 0.92f, 0.92f, 0.98f * alpha));

    fg->AddRectFilled(min, max, bg, 12.0f);
    fg->AddRect(min, max, bd, 12.0f, 0, 2.0f);

    ImVec2 text = ImVec2(center.x - text_size.x * 0.5f, center.y - text_size.y * 0.5f);
    fg->AddText(text, tx, msg);
}

// Compatibility helpers
void Toast(const std::string& text, float duration_sec) {
    ToastManager::I().Add(text, duration_sec);
}
void Toast(const char* text, float duration_sec) {
    ToastManager::I().Add(text ? std::string(text) : std::string(), duration_sec);
}

} // namespace ui