#include "imgui.h"
#include "ui/SystemPanels_Left.h"
#include "state/SimulationState.h"

namespace ui {
void DrawSystemPanelsLeft(core::SimulationState& /*sim*/)
{
    // Intentionally left minimal; panels render in their own translation units.
}
} // namespace ui
