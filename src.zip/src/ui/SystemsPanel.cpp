#include "imgui.h"
#include "imgui_internal.h"
#include "ui/SystemsPanel.h"

// Notes:
// - Uses ImGui docking/tab APIs only. No dependencies on engine state.
// - Windows use ImGuiCond_FirstUseEver for default layout (won't override user's saved layout).
// - You can later replace placeholder content with live game data per system.

namespace ui {

namespace {
// internal persistent state
struct SystemsState {
    bool openEconomy = true;
    bool openMilitary = true;
    bool openEspionage = true;
    bool openDiplomacy = true;
    bool openTrade = true;
    bool openTechnology = true;
    bool openPopulation = true;
    bool openFactions = true;
    bool openEvents = true;
    bool openCouncil = true;

    float bottomHeight = 260.0f; // default height for dock window
};
SystemsState& S() { static SystemsState s; return s; }

// --- Per-system placeholder draws ---
// Replace with real content later; keep them lightweight to avoid compile/link deps.
void DrawEconomy() {
    ImGui::TextUnformatted("Economy Overview");
    ImGui::Separator();
    ImGui::BulletText("Treasury: --");
    ImGui::BulletText("Income / Expense: -- / --");
    ImGui::BulletText("Production chains: --");
    ImGui::Dummy(ImVec2(0,4));
    ImGui::TextDisabled("Hook: connect to trade routes, production, prices, maintenance.");
}

void DrawMilitary() {
    ImGui::TextUnformatted("Military");
    ImGui::Separator();
    ImGui::BulletText("Armies: --");
    ImGui::BulletText("Garrisons: --");
    ImGui::BulletText("Readiness / Morale: --");
    ImGui::Dummy(ImVec2(0,4));
    ImGui::TextDisabled("Hook: terrain/weather modifiers, honored units, last-stand AI targets.");
}

void DrawEspionage() {
    ImGui::TextUnformatted("Espionage");
    ImGui::Separator();
    ImGui::BulletText("Agents active: --");
    ImGui::BulletText("Networks detected: --");
    ImGui::BulletText("Counter-espionage level: --");
    ImGui::Dummy(ImVec2(0,4));
    if (ImGui::CollapsingHeader("History Log")) {
        ImGui::TextDisabled("Hook: Show filtered espionage history with animations & signals.");
    }
    if (ImGui::CollapsingHeader("Assignments")) {
        ImGui::TextDisabled("Hook: Assign missions (sabotage, assassinations, tech theft).");
    }
}

void DrawDiplomacy() {
    ImGui::TextUnformatted("Diplomacy");
    ImGui::Separator();
    ImGui::BulletText("Relations matrix: --");
    ImGui::BulletText("Treaties / Access / Blockades: --");
    ImGui::BulletText("Reputation / Suspicion: --");
}

void DrawTrade() {
    ImGui::TextUnformatted("Trade");
    ImGui::Separator();
    ImGui::BulletText("Routes (dynamic, interruptible): --");
    ImGui::BulletText("Goods (supply/demand/prices): --");
    ImGui::BulletText("Espionage visibility on policies: --");
}

void DrawTechnology() {
    ImGui::TextUnformatted("Technology");
    ImGui::Separator();
    ImGui::BulletText("Tree progress: --");
    ImGui::BulletText("Unlocks pending: --");
    ImGui::BulletText("Doctrinal effects on AI: --");
}

void DrawPopulation() {
    ImGui::TextUnformatted("Population");
    ImGui::Separator();
    ImGui::BulletText("Growth / Migration / Disease: --");
    ImGui::BulletText("Culture / Assimilation: --");
    ImGui::BulletText("UI / Events / Roles: --");
}

void DrawFactions() {
    ImGui::TextUnformatted("Factions & Movements");
    ImGui::Separator();
    ImGui::BulletText("Estates power balance: --");
    ImGui::BulletText("Puppet leaders / councils: --");
    ImGui::BulletText("Risks: coups / scandals / reforms: --");
}

void DrawEvents() {
    ImGui::TextUnformatted("Events");
    ImGui::Separator();
    ImGui::BulletText("Active chains: --");
    ImGui::BulletText("Next decisions (AI hooks every 24 ticks): --");
    ImGui::BulletText("Localization / branches: --");
}

void DrawCouncil() {
    ImGui::TextUnformatted("Royal Council");
    ImGui::Separator();
    ImGui::BulletText("Advisors & tasks: --");
    ImGui::BulletText("Advice accuracy (skill/personality/ideology): --");
    ImGui::BulletText("Power & prestige effects: --");
}

// Small helper to draw a system tab if 'open' is true.
template<typename Fn>
void DrawSystemTab(const char* label, bool& open, Fn drawFn) {
    if (!open) return;
    if (ImGui::BeginTabItem(label, &open)) {
        drawFn();
        ImGui::EndTabItem();
    }
}

} // namespace

void DrawSystemsPanels() {
    auto& st = S();

    // Bottom dock-like window with tabs
    ImGuiViewport* vp = ImGui::GetMainViewport();
    // Default size/pos once; users can re-dock and layout will be saved by ImGui.
    ImGui::SetNextWindowViewport(vp->ID);
    ImGui::SetNextWindowSize(ImVec2(vp->WorkSize.x * 0.9f, st.bottomHeight), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x * 0.05f,
                                   vp->WorkPos.y + vp->WorkSize.y - st.bottomHeight - 6.0f),
                            ImGuiCond_FirstUseEver);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse;
    if (ImGui::Begin("Systems Dock", nullptr, flags)) {
        if (ImGui::BeginTabBar("SystemsTabs", ImGuiTabBarFlags_Reorderable | ImGuiTabBarFlags_AutoSelectNewTabs)) {
            DrawSystemTab("Economy",     st.openEconomy,     DrawEconomy);
            DrawSystemTab("Military",    st.openMilitary,    DrawMilitary);
            DrawSystemTab("Espionage",   st.openEspionage,   DrawEspionage);
            DrawSystemTab("Diplomacy",   st.openDiplomacy,   DrawDiplomacy);
            DrawSystemTab("Trade",       st.openTrade,       DrawTrade);
            DrawSystemTab("Technology",  st.openTechnology,  DrawTechnology);
            DrawSystemTab("Population",  st.openPopulation,  DrawPopulation);
            DrawSystemTab("Factions",    st.openFactions,    DrawFactions);
            DrawSystemTab("Events",      st.openEvents,      DrawEvents);
            DrawSystemTab("Council",     st.openCouncil,     DrawCouncil);
            ImGui::EndTabBar();
        }

        // Simple controls row
        ImGui::Separator();
        ImGui::TextDisabled("Show Tabs:");
        ImGui::SameLine();
        ImGui::Checkbox("Eco", &st.openEconomy); ImGui::SameLine();
        ImGui::Checkbox("Mil", &st.openMilitary); ImGui::SameLine();
        ImGui::Checkbox("Esp", &st.openEspionage); ImGui::SameLine();
        ImGui::Checkbox("Dip", &st.openDiplomacy); ImGui::SameLine();
        ImGui::Checkbox("Trade", &st.openTrade); ImGui::SameLine();
        ImGui::Checkbox("Tech", &st.openTechnology); ImGui::SameLine();
        ImGui::Checkbox("Pop", &st.openPopulation); ImGui::SameLine();
        ImGui::Checkbox("Factions", &st.openFactions); ImGui::SameLine();
        ImGui::Checkbox("Events", &st.openEvents); ImGui::SameLine();
        ImGui::Checkbox("Council", &st.openCouncil);
    }
    ImGui::End();
}

} // namespace ui